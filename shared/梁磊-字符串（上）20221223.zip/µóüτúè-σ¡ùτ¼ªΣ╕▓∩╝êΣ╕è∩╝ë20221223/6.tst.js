// 三向单词查找树

const R = 128;

class Node {
    c = null;       // 字符
    left = null;    // 左
    right = null    // 右
    mid = null;     // 中
    value = null;   // 字符串关联值

    // next = [null,....26];
}


class TST {
    root = new Node();
    get(key) {
        let x = this._get(this.root, key, 0)
        if( x==null) return null;
        return x.value;
    }
    _get(x, key, d) {
        if( x==null) return null;

        let c = key[d];

        if(c < x.c) {
            return this._get(x.left, key, d)
        }else if(c>x.c) {
            return this._get(x.right, key, d)

        }else if(d < key.length - 1) {
            return this._get(x.mid, key, d + 1)
        }
        return x;
    }

    put(k,v){
        this.root = this._put(this.root,k,v,0)
    }

    _put(x, key, val, d) {
        if( x==null)  {
            x = new Node();
            x.val = val;
        }
        let c = key[d];
        if(c < x.c) {
            x.left = this._put(x.left, key,val, d)
        }else if(c>x.c) {
            x.right = this._put(x.right, key,val, d)
        }else if(d < key.length - 1) {
            x.mid = this._put(x.mid, key,val, d + 1)
        }else {
            x.val = val;
        }
        return x;

    }
}