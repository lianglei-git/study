/* 
 * MSD - 高位优先排序
  在低位优先排序中，可能会出现一点问题。比如字符串“ab”与“ba”，
  长度为2需要进行两次排序，第一次排序结果为“ba”、“ab”，第二次排序结果为“ab”、“ba”，
  第一次排序的结果对第二次毫无意义，这就造成了时间上的浪费。
  而在高位优先排序中，只会进行一次排序。结果为“ab”、“ba”。
*/


class MSD {
    R = 128;
    M = 9;
    aux = [];
    charAt(s, d) {
        if (s.length > d) {
            return s[d].charCodeAt() ;
        }
        return -1
    }
    sort(a) {
        let N = a.length;
        this.aux = Array(N).fill(0);
        this._sort(a, 0, N - 1, 0);
    }
    /**
     * 
     * 第2，3，4参数就是每次分组的参数，
     * @param {*} a  字符串数组
     * @param {*} lo 起始位置
     * @param {*} hi 字符串长度
     * @param {*} d  从每项第几位开始
     */
    _sort(a, lo, hi, d) {
        // 我们会用插入排序对排序数组较小的时候进行优化，这样可以大大提高MSD的效率。
        // 对于小型子数组的处理，记下这里的用法，后面会有相似之处
        // if(hi <= lo + this.M) {
        //     for (let i = lo; i <= hi; i++)	//插入排序
        //     {
        //         // lo = 2
        //         let key = a[i]; // seashells
        //         let j = i - 1; // j = 1
        //         while (j >= 0 && key < a[j])
        //         {
        //             a[j + 1] = a[j];
        //             j--;
        //         }
        //         a[j + 1] = key;
        //     }
        //     return;
        // }
        
        const count = Array(this.R + 2).fill(0);

        for (let i = lo; i <= hi; i++) {
            count[this.charAt(a[i], d) + 2]++;
        }

        for (let i = 0; i < this.R + 1; i++) {
            count[i + 1] += count[i]
        }

        for (let i = lo; i <= hi; i++) {
            this.aux[count[this.charAt(a[i], d) + 1]++] = a[i];
        }

        for (let i = lo; i <= hi; i++) {
            a[i] = this.aux[i - lo]
        }
        for (let r = 0; r < this.R; r++) {
            // 进行分组， 把分组的位置开始，结束，及从每个的第几位进行下次记录转换。
            this._sort(a, lo + count[r], lo + count[r + 1] - 1, d + 1)
        }
    }
}

let arr = [
'she',
'sells',
'seashells',
'by',
'the',
'seashore',
'the',
'shells',
'she',
'sells',
'are',
'surely',
'seashells'
]
let msd = new MSD();

msd.sort(arr);

console.log(arr)



