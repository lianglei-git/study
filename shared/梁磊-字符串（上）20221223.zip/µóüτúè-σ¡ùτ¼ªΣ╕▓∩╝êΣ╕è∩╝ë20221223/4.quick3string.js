// 三向字符串快速排序（Quick3string）
class Quick3String {
  exch(s, a, b) {
    let temp = s[a];
    s[a] = s[b];
    s[b] = temp;
  }

  charAt(str, d) {
    if (d < str.length) {
      return str[d].charCodeAt();
    }
    return -1;
  }

  sort(arr) {
    this._sort(arr, 0, arr.length - 1, 0);
  }

  _sort(a, lo, hi, d) {
    // 迭代结束判断，如果迭代到了只剩余1个元素，无需继续进行下面操作，防止死循环；
    if (hi <= lo) return;
    // “小于参照物的指针”【lt】、“大于参照物的指针”【gt】，以及“当前指针”【i】
    let lt = lo,
      gt = hi;
    let v = this.charAt(a[lo], d); // 使用当前排序部分的第lo元素作为参照物；
    let i = lo + 1;
    // 元素替换
    while (i <= gt) {
      let t = this.charAt(a[i], d);
      if (t < v) {
        this.exch(a, lt++, i++); // 第一次排序的时候就已经开始分组了， lt++
      } else if (t > v) {
        this.exch(a, i, gt--); // gt-- 
      } else {
        // 跟参照物对比也有可能等于本身
        i++;
      }
    }

    /*
     ['sddd','dfff','abb', 'skk','soo','sll', 'vo','tl','zo']
     第一次分组
        dfff,abb           =>  第一组  => lo   = 0, lt-1 = 1
        sddd,skk,soo,sll   =>  第二组  => lt   = 2, gt   = 5
        vo,tl,zo           =>  第三组  => gt+1 = 6, hi   = 8
    */
    this._sort(a, lo, lt - 1, d);
    if (v >= 0) { // 小于到大于区间
        // 进行子序列拆分，并从第二位开始
      this._sort(a, lt, gt, d + 1);
    }
    this._sort(a, gt + 1, hi, d);
  }
}

let arr = [
  "she",
  "sells",
  "seashells",
  "by",
  "the",
  "seashore",
  "the",
  "shells",
  "she",
  "sells",
  "are",
  "surely",
  "seashells",
];

const arr2 = ['sddd','dfff','abb', 'skk','soo','sll', 'vo','tl','zo']

let q3s = new Quick3String();
q3s.sort(arr2);
