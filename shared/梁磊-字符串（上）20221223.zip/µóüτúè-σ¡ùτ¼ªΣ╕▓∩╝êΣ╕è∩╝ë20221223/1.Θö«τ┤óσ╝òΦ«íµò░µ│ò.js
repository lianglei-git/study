/**

关于键索引计数法进行字符串排序，并不是全部都适用，因为它的排序算法核心就是通过统计元素出现频次、构建排序因子的索引边界来递进式完成所有元素排序，它主要适合于以下场景

1. 用于小整数键的算法
    arr = [1,2,3,4,2,3,4,2,1,3,4,2,3,4]
2. 用于小整数键的分组排序
    arr = [{a,1}、{b,2}、{c,1}、{d,2}、{e,3}、{f,4}、{g,4}、{h,1}]

分四步
1. 频率统计
     对于这个分组 [{a,1}、{b,2}、{c,1}、{d,2}、{e,3}、{f,4}、{g,4}、{h,1}]
   分组       元素       元素出现频次
    1	=>  a、c、h   =>  1出现3次  
    2	=>  b、d      =>  2出现2次  
    3	=>  e        =>  3出现1次
    4	=>  f、g      =>  4出现2次

2. 构建索引
    0 -(分组1)> 3 -(分组2)> 5 -(分组3)> 6 -(分组4)> 8
    统计频次的目的是为了给构建索引提供条件，我们知道所谓键索引计数就是通过索引 + 频次来完成的。
    索引可以理解为每个分组的排序边界，每个分组的起始索引即较小一侧边界，
    而每个分组的结束索引即较大一侧边界，如果索引边界为startIndex，endIndex，
    分组内元素出现频次为t，那么每个分组中的索引边界和分组内元素出现频次的关系是endIndex = startIndex + t，
    每个分组都按照逻辑序号紧紧相邻，较大的分组起始索引与它相邻的第一个较小分组的结束索引一致。
3. 数据分类
    把构建好的索引数组找到原始数组的位置进行匹配;
4. 回写数组
 */



// [2,1,3,2,2,1,3,0,0]
const IndexCountSortDemo = (nums) => {
    let count = Array(nums.length).fill(0); // [2,1,0,0,0,0,0]
    //计算频率
    for (let i = 0; i < nums.length; i++) {
        // 数组第0个永远是0， 起始位置总为0
        // 数组第一项目如果是0的话就有值了（0+1）第一项
        count[nums[i] + 1]++;
    }
    
    console.log(count,'count')
    //将频率转化为索引
    for (let i = 1; i < count.length; i++) {
        count[i] = count[i] + count[i - 1];
    }
    console.log(count,'count')

    //数据分类
    let aux = new Array(nums.length);
    for (let i = 0; i < nums.length; i++) {
        aux[count[nums[i]]++] = nums[i];
        //aux[count[nums[i]]] = nums[i];
        //count[nums[i]]++;
    }

    //回写数据（这里是打印）
    // for (let i = 0; i < nums.length; i++) {
    //     console.log(aux[i]);
    // }
}

// IndexCountSortDemo([2, 3, 4, 1, 2, 4, 3, 1, 2, 2, 1, 0])
IndexCountSortDemo([2,1,3,2,2,1,3])



const IndexCountSortDemo2 = (arr) => {
    let count = new Array(arr.length).fill(0);
    //计算频率
    for (let i = 0; i < arr.length; i++) {
        count[arr[i].group + 1]++;
    }
    //将频率转化为索引
    for (let i = 1; i < count.length; i++) {
        count[i] = count[i] + count[i - 1];
    }

    //数据分类
    let aux = new Array(arr.length);
    for (let i = 0; i < arr.length; i++) {
        aux[count[arr[i].group]++] = arr[i];
        // aux[count[arr[i].group]] = arr[i];
        // count[arr[i].group]++;
    }
    //回写数据（这里是打印）
    // for (let i = 0; i < arr.length; i++) {
    //     console.log(aux[i] + " ");
    // }
}

// IndexCountSortDemo2([
//     {data: 'a',group: 1},{data:'b',group:2},{data:'c',group:1},{data:'d',group:2},{data:'e',group:3},{data:'f',group:4},{data:'g',group:4},{data:'h',group:1}
// ])


/*
[{a,1}, {c,1}, {h;1}, {b,2}, {d,2}, {e,3}, {f,4}, {g,4}]
参考： https://blog.csdn.net/u013161278/article/details/115493943

*/

