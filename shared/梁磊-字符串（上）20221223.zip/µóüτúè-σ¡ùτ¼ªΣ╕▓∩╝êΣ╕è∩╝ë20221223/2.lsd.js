// 低位优先算法

const arr = [
'4PGC938',
'2IYE230',
'3CIO720',
'1ICK750',
'1OHV845',
'4JZY524',
'1ICK750',
'3CIO750',
'1OHV845',
'1OHV845',
'2RLA629',
'2RLA629',
'3ATW723'
]

// ['ab', 'ba'];
// ['ba', 'ab'];
// ['ab', 'ba']
const LSD = (a,w) => {
    let N = a.length;
    let R = 128;
    const aux = Array(N).fill(0);
    for(let d = w - 1; d >= 0; d--) {
        let count = Array(R).fill(0);

        for (let i = 0; i < N; i++) //计算出现频率
            count[a[i][d].charCodeAt() + 1]++;

        for (let r = 0; r < R; r++) //将频率转换为索引
            count[r + 1] += count[r];

        for (let i = 0; i < N; i++) //将元素分类
            aux[count[a[i][d].charCodeAt()]++] = a[i];

        
        // for (let i = 0; i < N; i++) //回写
            // a[i] = aux[i];
    } 
    console.log(aux)
}

LSD(arr, 7)