// kmp算法
// abadaa
// 001231


// 创建前缀表

/**
 * 
 * @param {*} pattern 
 * @param {*} prefix 
 * @param {*} n 
 */
function prefix_table(pattern) {
    let n = pattern.length;
    let prefix = new Array(n);
    // 比较的长度
    let len = 0;
    // 不考虑第一次，因为第一次检测的字母，永远是0，所以检测字母也从第2个开始
    prefix[0] = 0;
    // 检测 i 字母 
    let i = 1; //  前缀表第一个字母已经不用填了，因为第一个已经是0了

    while(i < n) {
        // 检测当前字母和比较长度的字母是不是相等
        /**
         * pattern = ababc；一样长度的前缀表[0,0,1，?,?]来表示
         * 现在要你填写第四位和第五位
         * 现在i=3,len=1;pattern[3]==pattern[1]；
         * 等于的话 i 和 len都加一；
         * 
         */
        if(pattern[i] == pattern[len]) {
            len++;
            prefix[i] = len;
            i++;
        } else  {
            if(len > 0) {
                len = prefix[len - 1];
            }else {
                prefix[i] = 0;
                i++;
            }
        }
    }

    // 格式化向后推迟一位的前缀表
    // prefix.pop();
    prefix.unshift(-1);

    return prefix;
}


function kmp_search(text, pattern) {
    const prefix = prefix_table(pattern);

    let i = 0, j= 0, m = text.length;

    while(i<m){
        if(j == pattern.length - 1) {
            console.log('匹配成功', i - j);
            return i-j;
        }
        if(text[i] == pattern[j]){
            i++;
            j++
        }else {
            j = prefix[j];
            if(j == -1) {
                i++;
                j++;
            }
        }
    }
}

const pt = prefix_table('abcabc')

console.log(pt);