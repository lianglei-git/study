// 单词查找树
const R=26;

class Node {
    value = null;
    next = Array(R).fill(null);
}


class TrieST {
    _root = new Node();
    _get(x,key,d) {
        if(x == null) return null;
        if(d == key.length) return x;
        let c = key[d];
        return this._get(x.next[c], key, d + 1);
    }
    _put(x,key,value,d){
        if(x == null) {
            x = new Node();
        }
        if(d == key.length) {
            x.value = value
            return x;
        }
        let c = key[d];
		x.next[c] = this._put(x.next[c], key, value, d + 1);
		return x;
    }
    get(key){
        let x = this._get(this._root, key, 0);
        if(x == null) return null;
        return x.value;
    }

    put(key, value) {
        this._root = this._put(this._root, key, value, 0);
    }

    // 筛选
    getRoot(x, p = []) {
        for(let k in x.next) {
            if(x.next[k] != null) {
                p[k] = x.next[k];
                p[k].next = this.getRoot(x.next[k])
            }
        }
        return p
    }
    // 因为根的值 是一个空，所以直接输出next了
    get root() {
        return this.getRoot(this._root);
    }

    keys(){
        // 默认为通配符匹配
        return this.keysWithPrefix("");
    }

 /**
     * 获取所有以pre字符串为前缀的字符串，
     * she、shells、hello、by 以sh为前缀的字符串有she、shells
     */
    keysWithPrefix(pre){
        let queue = new Array();
        this.collect(this._root,pre,queue)
        return queue;
    }

    collect(x, pre, queue) {
        if (x==null) return;                      //1、如果遇到空结点，就返回
        if (x.value!=null) queue.push(pre);      //2、如果该结点的值不为空，那么该字符串存在加入到队列中 
 
        for(let c in x.next) { //3、遍历该结点的所有可能存在的下一个结点，重复上面的1、2步将所有以pre 为前缀的字符串加入到队列中
            this.collect(x.next[c],pre+c,queue);  
        }
    }

    delete(key){
        // this._root = 
        this._delete(this._root, key, 0)
    }

    /**
     * 删除指定String字符串 会有两种情况：
     * 一种是该字符串树枝后面还有其他字符串，这样将该结点的val值置空就可以了
     * 第二种是删除的字符串单独占着一个树枝，这样就需要将这个树枝上所有的字符结点置空
     * @param x    查询到当前结点
     * @param key  删除的字符串
     * @param d    走到key的第一个字符
     * @return     将本结点的信息返回给上一个结点。
     */
    _delete(x, key, d) {
        if (x==null)return  null;
        if (d == key.length) {
            x.value=null;
        }else {
            let c = key.charAt(d);
            x.next[c] = this._delete(x.next[c], key, d + 1);
        }

        if(x.value!=null) return x;

        for(let c in x.next) {
            if ( x.next[c] != null) return x;
        }
        return null
    }

    // 获取最长前缀
    longestPrefixOf(s) {
        let length = this._search(this._root, s, 0, 0);
        return s.substring(0, length);
    }

    _search(x, s,d, length){
        if(x == null) return length;
        if(x.value != null) length = d;
        if(d == s.length) return length;
        let c = s[d];
        return this._search(x.next[c], s, d+1, length)
    }
}


const trie = new TrieST();

trie.put('by', 3)
trie.put('she', 2)
trie.put('are', 1)
trie.put('acn', 4)
trie.put('app', 5)
trie.put('appenf', 7)
trie.put('appifcms', 8)

// trie.delete('by')
// trie.delete('acn')

console.log(trie)
// console.log(trie.get('a'))
// console.log(trie.root, 'trie');

// console.log(trie.keys())

console.log(trie.longestPrefixOf('appifcs'))
