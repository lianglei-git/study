
function search(p, t) {
    let M = p.length, N = t.length;

    for(let i = 0; i <= M - N; i++){
        let j = 0;
        for(;j < N;j++){
            if(p[i+j] != t[j]) break;
        }
        if(j == N) return i;
    }

    return N;
}


console.log(search(
    'abasdadsjkpof',
    'jkp'
))

