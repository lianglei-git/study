export var FunctionComponent = 0; // 函数组件
export var ClassComponent = 1; // 类组件
export var IndeterminateComponent = 2; // 还不知道是函数组件 类组件

export var HostRoot = 3; // 根组件 Root of a host tree. Could be nested inside another node.

// var HostPortal = 4; // A subtree. Could be an entry point to a different renderer.

export var HostComponent = 5; // 原生Dom节点


