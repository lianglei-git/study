import * as React from 'react'
import * as ReactDOM from 'react-dom'
import './index.css'

// 测试useState的
// import './record/testUseState' // ✅

// 我们自己实现 hooks
import './record/reWriteApp' // ✅ 



// 原始版本的react
// import App from './record/App'
// // debugger
// ReactDOM.render(<App />, document.getElementById('root'));

