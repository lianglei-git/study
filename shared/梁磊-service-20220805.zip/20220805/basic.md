### &nbsp; PWA渐进式应用
---
>概念：  
&emsp; PWA 是 Google 于 2016 年提出的概念，于 2017 年正式落地，于 2018 年迎来重大突破，全球顶级的浏览器厂商，Google、Microsoft、Apple 已经全数宣布支持 PWA 技术。  
&emsp; PWA 全称为 Progressive Web App，中文译为渐进式 Web APP，其目的是通过各种 Web 技术实现与原生 App 相近的用户体验。  
&emsp; 纵观现有 Web 应用与原生应用的对比差距，如离线缓存、沉浸式体验等等，可以通过已经实现的 Web 技术去弥补这些差距，最终达到与原生应用相近的用户体验效果。  

单独提起`PWA`、或`serive worker`概念时，往往都不能独善其身，而双方些许有些藕断丝连。尝试理清二者关系


### PWA
&emsp;Web 应用和 Native 应用有着各自不同的优势和使用场景  PWA 结合了二者的优势  
&emsp;Web 应用的资源存储在服务器，Native 的资源存储在本地。所以 Native 会比 Web 应用的加载速度和流畅性方面获得更好地表现；  
&emsp;PWA旨在创造拥有更加流畅的用户体验的 Web 应用，和创建类 Native App 的沉浸式效果，而非浏览器端那样的外观和体验；   
&emsp;在各种网络和数据加载的条件下仍然可用－它可以在网络不稳定或者没有网络的情况下使用。


`Service Worker` 是PWA的关键技术，可以支持一些原生应用的功能
1. 友好的弱网和离线体验
2. 定期的后台同步
3. 推送通知


- [Web Worker](./source/webworker/README.md)
- [Service Worker](source/serviceworker/README.md)