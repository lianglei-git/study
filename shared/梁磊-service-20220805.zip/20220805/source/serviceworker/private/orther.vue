<template>
    <div> 被加载出来的VUE 模版 </div>
</template>