declare module 'date-fns/set_hours' {
  import {setHours} from 'date-fns'
  export = setHours
}
