declare module 'date-fns/set_day' {
  import {setDay} from 'date-fns'
  export = setDay
}
