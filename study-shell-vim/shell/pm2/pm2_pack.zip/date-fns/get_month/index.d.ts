declare module 'date-fns/get_month' {
  import {getMonth} from 'date-fns'
  export = getMonth
}
