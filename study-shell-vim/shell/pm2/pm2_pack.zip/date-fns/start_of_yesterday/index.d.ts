declare module 'date-fns/start_of_yesterday' {
  import {startOfYesterday} from 'date-fns'
  export = startOfYesterday
}
