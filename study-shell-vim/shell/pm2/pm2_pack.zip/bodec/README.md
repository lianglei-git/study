bodec
=====

Binary ops using typed arrays
